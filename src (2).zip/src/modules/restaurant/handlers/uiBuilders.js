/**
 * modules/restaurant/handlers/uiBuilders.js
 *
 * [FIX-BUG11] buildAdminOrderAlertBody no longer hardcodes "Cash / On delivery".
 *             It now checks payment.enabled to show the correct payment mode.
 * [FIX-BUG14] buildMenuUI returns a Contact Us button on empty menu (not plain text).
 */

export function buildMenuUI(business) {
  const items = (business?.menuItems || []).filter(i => i.available !== false);
  if (!items.length) {
    // [FIX-BUG14] Return a button so there's somewhere to go
    return {
      type:    'buttons',
      body:    '⚠️ Our menu is being updated. Please contact us directly or check back soon.',
      buttons: [{ id: 'SUPPORT', title: '💬 Contact Us' }],
    };
  }
  // [FIX-LIST-CAP-2] This is a flat, uncategorised list — unlike bakery/
  // electronics/cosmetics, the restaurant module has no category browsing
  // step to naturally keep any one list under Meta's real 10-row-total cap.
  // dispatcher.js now truncates to 10 and adds a footer hint rather than
  // rejecting the send, but a menu with more than 10 items will still hide
  // items past #10 from this view — add category browsing here (mirroring
  // _buildCategoryUI in bakery/orderFlow.js) if that becomes a problem.
  const rows = items.map((item, i) => ({
    id:          String(i + 1),
    title:       item.name.slice(0, 24),
    description: [item.description, item.price ? `${business?.payment?.currency || 'D'}${item.price}` : ''].filter(Boolean).join(' — ').slice(0, 72),
  }));
  return {
    type:        'list',
    header:      business?.name || 'Menu',
    body:        "Here's our menu — choose an item:",
    buttonLabel: 'View Menu',
    rows,
  };
}

// [MULTICART-FLOW-1] Shown while the customer is assembling a multi-item cart
// (typed "2 burgers and a coke" — see utils/multiItemParser.js). Lets them
// keep adding items conversationally, checkout, or cancel.
export function buildCartSummaryUI(lines, business) {
  const currency  = business?.payment?.currency || 'D';
  const allPriced = lines.every(l => typeof l.item.price === 'number');
  const total     = allPriced ? lines.reduce((sum, l) => sum + l.item.price * l.quantity, 0) : null;
  const rows = lines
    .map(l => `• *${l.quantity}× ${l.item.name}*${typeof l.item.price === 'number' ? ` — ${currency}${l.item.price * l.quantity}` : ''}`)
    .join('\n');

  return {
    type: 'buttons',
    body: `🛒 *Your Cart*\n\n${rows}${total !== null ? `\n\n💰 Total: *${currency}${total}*` : ''}\n\nWhat would you like to do?`,
    buttons: [
      { id: 'CART_CHECKOUT', title: '✅ Checkout'  },
      { id: 'CART_ADD_MORE', title: '➕ Add More'  },
      { id: 'CANCEL',        title: '❌ Cancel'    },
    ],
  };
}

// [MULTICART-FLOW-1] Cart-aware equivalent of buildOrderSummary — shown at
// the CONFIRM step when the order has multiple lines instead of one item.
export function buildCartOrderSummary(lines, total, business) {
  const currency = business?.payment?.currency || 'D';
  const rows = lines.map(l => `🍽 *${l.quantity}× ${l.item.name}*`).join('\n');
  return {
    type: 'buttons',
    body: `🧾 *Order Summary*\n\n${rows}${total ? `\n\n💰 Total: *${currency}${total}*` : ''}\n\nConfirm your order?`,
    buttons: [
      { id: 'CONFIRM', title: '✅ Confirm Order' },
      { id: 'CANCEL',  title: '❌ Cancel'        },
    ],
  };
}

export function buildOrderSummary({ item, qty, total, addOns = [], business }) {
  const name     = typeof item === 'object' ? item.name : item;
  const currency = business?.payment?.currency || 'D';
  const addOnStr = addOns.length ? `\n➕ Add-ons: ${addOns.join(', ')}` : '';
  return {
    type: 'buttons',
    body: `🧾 *Order Summary*\n\n🍽 *${qty}× ${name}*${addOnStr}${total ? `\n💰 Total: *${currency}${total}*` : ''}\n\nConfirm your order?`,
    buttons: [
      { id: 'CONFIRM', title: '✅ Confirm Order' },
      { id: 'CANCEL',  title: '❌ Cancel'        },
    ],
  };
}

export function buildOrderSuccess({ item, qty, business }) {
  const name     = typeof item === 'object' ? item.name : (item || 'your item');
  const quantity = qty || 1;

  // [FIX-GOODBYE-1] Previously bundled "Place New Order / Book a Table / Start
  // Over" buttons into the SAME message as the thank-you — the bot said goodbye
  // and immediately asked "what would you like to do next?" in one breath,
  // which read as fake/contradictory to customers. This now ends the message
  // as a genuine close: plain text, no buttons. The conversation only resumes
  // if the customer messages again, via the normal returning-customer greeting
  // path in moduleRouter.js.
  return {
    type: 'text',
    body: `✅ *Order placed!*\n\n🍳 *${quantity}× ${name}* — we're preparing it now.\n\nThank you! 😊`,
  };
}

// [MULTICART-FLOW-1] Cart-aware equivalent of buildOrderSuccess — `itemsLabel`
// already carries each line's own quantity (e.g. "2× Burger, 1× Coke"), so
// unlike buildOrderSuccess it is NOT re-prefixed with an outer quantity.
export function buildCartOrderSuccess(itemsLabel) {
  return {
    type: 'text',
    body: `✅ *Order placed!*\n\n🍳 *${itemsLabel}* — we're preparing it now.\n\nThank you! 😊`,
  };
}

/**
 * buildAdminOrderAlertBody
 * [FIX-BUG11] Shows correct payment mode — no longer hardcodes "Cash / On delivery"
 *             when the business has Wave payment enabled.
 */
export function buildAdminOrderAlertBody({ customerPhone, item, quantity, totalPrice, addOns = [], shortId, business }) {
  const bizName    = business?.name || 'Business';
  const currency   = business?.payment?.currency || 'D';
  const payEnabled = business?.payment?.enabled;
  const addOnStr   = addOns?.length ? `\n➕ Add-ons: ${addOns.join(', ')}` : '';
  const priceStr   = totalPrice ? `\n💰 Total: *${currency}${totalPrice}*` : '';
  const idStr      = shortId ? `\n🔖 Ref: \`${shortId}\`` : '';
  // [FIX-BUG11] Check actual payment configuration; channel-agnostic label
  const paymentMode = payEnabled && totalPrice
    ? `*Screenshot verification pending*`
    : `*Cash / On delivery*`;

  return (
    `🔔 *New Order — ${bizName}*\n\n` +
    `👤 Customer: ${customerPhone}\n` +
    `🍽 *${quantity}× ${item}*${addOnStr}${priceStr}${idStr}\n\n` +
    `💵 *Payment:* ${paymentMode}\n\n` +
    `Status: *Pending* — please prepare.`
  );
}

/** @deprecated — use buildAdminOrderAlertBody */
export function buildAdminOrderAlert(args) {
  return buildAdminOrderAlertBody(args);
}
