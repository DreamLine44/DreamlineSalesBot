// tests/multiCartFlowWiringVerticals2.test.mjs
//
// [MULTICART-FLOW-1] Wiring guards for the retail, delivery, salon, and
// fashion rollout of the multi-item cart flow — the second batch, following
// multiCartFlowWiringVerticals.test.mjs (bakery/cosmetics/electronics) and
// multiCartFlowWiring.test.mjs (restaurant). Same source-text-guard approach:
// these flow files pull in Mongoose/session deps unsafe to exercise without a
// live DB.
//
// Run with: node --test src/tests/

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

function read(relPath) {
  return fs.readFileSync(new URL(relPath, import.meta.url), 'utf8');
}

// retail and fashion have their own per-item variant sub-flow (SELECT_VARIANT /
// SELECT_SIZE+SELECT_COLOR) with no per-cart-line equivalent, so cart entry is
// additionally gated on every matched item having zero variants. delivery and
// salon's product-order sub-flow have no variant step at all, so 2+ matches
// is the only gate.
const verticals = [
  { name: 'retail',   path: '../modules/retail/flows/index.js',   variantGated: true  },
  { name: 'delivery', path: '../modules/delivery/flows/index.js', variantGated: false },
  { name: 'salon',    path: '../modules/salon/flows/index.js',    variantGated: false },
  { name: 'fashion',  path: '../modules/fashion/flows/index.js',  variantGated: true  },
];

for (const { name, path, variantGated } of verticals) {
  const src = read(path);
  // salon's file has three flows (walk-in, booking, product-order), each with
  // their own CONFIRM/CART_REVIEW-shaped step — scope to the product-order
  // function so we test the one that actually has cart wiring.
  const scopeStart = name === 'salon' ? src.indexOf('export async function handleSalonProductOrder') : 0;

  test(`${name}: imports the shared multi-item parser`, () => {
    assert.match(src, /extractCartLines.*from ['"]\.\.\/\.\.\/\.\.\/utils\/multiItemParser\.js['"]/);
  });

  test(`${name}: SELECT_ITEM gates the cart branch on 2+ matched items`, () => {
    const selectStart = src.indexOf("case 'SELECT_ITEM'", scopeStart);
    assert.ok(selectStart !== -1, `${name}: SELECT_ITEM case not found`);
    const cartParseIdx = src.indexOf('extractCartLines(raw,', selectStart);
    assert.ok(cartParseIdx !== -1, `${name}: expected extractCartLines() call inside SELECT_ITEM`);
    const gateSlice = src.slice(cartParseIdx, cartParseIdx + 400);
    assert.match(gateSlice, /matchedCount\s*>=\s*2/, `${name}: cart branch must require 2+ distinct matched items`);
    if (variantGated) {
      assert.match(gateSlice, /_hasNoVariants/, `${name}: cart branch must also require every matched line to have zero variants`);
    }
  });

  test(`${name}: a CART_REVIEW step exists and handles checkout, add-more, and merging`, () => {
    const start = src.indexOf("case 'CART_REVIEW'", scopeStart);
    assert.ok(start !== -1, `${name}: CART_REVIEW case not found`);
    const body = src.slice(start, start + 3000);
    assert.match(body, /wantsCheckout/);
    assert.match(body, /wantsAddMore/);
    assert.match(body, /_mergeCartLines/, `${name}: new items typed mid-review must merge into the existing cart`);
  });

  test(`${name}: _mergeCartLines sums quantities for a repeated item`, () => {
    const start = src.indexOf('function _mergeCartLines');
    assert.ok(start !== -1, `${name}: _mergeCartLines helper not found`);
    const body = src.slice(start, start + 700);
    assert.match(body, /existing\.quantity\s*\+=/);
  });

  test(`${name}: CONFIRM is cart-aware`, () => {
    const start = src.indexOf("case 'CONFIRM'", scopeStart);
    assert.ok(start !== -1, `${name}: CONFIRM case not found`);
    const body = src.slice(start, start + 3500);
    assert.match(body, /isCart/);
  });
}

// retail and fashion: saveOrder's items[] contract, gated on _hasNoVariants
for (const name of ['retail', 'fashion']) {
  test(`${name}: cart entry is gated on zero variants (no per-line variant sub-flow exists)`, () => {
    const path = name === 'retail' ? '../modules/retail/flows/index.js' : '../modules/fashion/flows/index.js';
    const src = read(path);
    const selectStart = src.indexOf("case 'SELECT_ITEM'");
    const cartParseIdx = src.indexOf('extractCartLines(raw,', selectStart);
    const gateSlice = src.slice(cartParseIdx, cartParseIdx + 400);
    assert.match(gateSlice, /_hasNoVariants/, 'an item with variants must not silently enter the cart flow without its variant being collected');
  });
}

test('retail: CONFIRM saves cart orders through the real items[] contract', () => {
  const src = read('../modules/retail/flows/index.js');
  const start = src.indexOf("case 'CONFIRM'");
  const body = src.slice(start, start + 3500);
  assert.match(body, /items:\s*isCart/, 'saveOrder() must pass items[] when isCart');
  assert.match(body, /unitPrice:\s*typeof l\.item\.price === 'number' \? l\.item\.price : undefined/, 'partial pricing must pass through as undefined, not 0');
});

test('delivery: CONFIRM saves cart orders through the real items[] contract', () => {
  const src = read('../modules/delivery/flows/index.js');
  const start = src.indexOf("case 'CONFIRM'");
  const body = src.slice(start, start + 3500);
  assert.match(body, /items:\s*isCart/, 'saveOrder() must pass items[] when isCart');
});

test('salon: CONFIRM saves cart orders through the real items[] contract', () => {
  const src = read('../modules/salon/flows/index.js');
  const scopeStart = src.indexOf('export async function handleSalonProductOrder');
  const start = src.indexOf("case 'CONFIRM'", scopeStart);
  const body = src.slice(start, start + 3500);
  assert.match(body, /items:\s*isCart/, 'saveOrder() must pass items[] when isCart');
});

test('fashion: CONFIRM saves cart orders through the real items[] contract', () => {
  const src = read('../modules/fashion/flows/index.js');
  const start = src.indexOf("case 'CONFIRM'");
  const body = src.slice(start, start + 3500);
  assert.match(body, /items:\s*isCart/, 'saveOrder() must pass items[] when isCart');
});

test('retail: cart checkout skips SELECT_VARIANT/QUANTITY straight to FULFILMENT', () => {
  const src = read('../modules/retail/flows/index.js');
  const start = src.indexOf("case 'CART_REVIEW'");
  const body  = src.slice(start, start + 1500);
  assert.match(body, /step:\s*'FULFILMENT'/);
});

test('delivery: cart checkout skips the per-item QUANTITY step straight to DELIVERY_ADDRESS', () => {
  const src = read('../modules/delivery/flows/index.js');
  const start = src.indexOf("case 'CART_REVIEW'");
  const body  = src.slice(start, start + 1500);
  assert.match(body, /step:\s*'DELIVERY_ADDRESS'/);
});

test('salon: cart checkout skips QUANTITY straight to CONFIRM (product-order sub-flow only)', () => {
  const src = read('../modules/salon/flows/index.js');
  const start = src.indexOf("case 'CART_REVIEW'");
  const body  = src.slice(start, start + 1500);
  assert.match(body, /step:\s*'CONFIRM'/);
});

test('fashion: cart checkout skips SELECT_SIZE/SELECT_COLOR/QUANTITY straight to CONFIRM', () => {
  const src = read('../modules/fashion/flows/index.js');
  const start = src.indexOf("case 'CART_REVIEW'");
  const body  = src.slice(start, start + 1500);
  assert.match(body, /step:\s*'CONFIRM'/);
});
