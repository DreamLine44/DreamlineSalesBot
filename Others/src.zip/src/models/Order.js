/**
 * models/Order.js
 *
 * Stores customer orders with full payment lifecycle support.
 *
 * idempotencyKey: auto-generated UUID per order — prevents duplicate key errors
 * on the (tenantId, customerPhone, idempotencyKey) compound index.
 *
 * paymentStatus tracks payment lifecycle (screenshot-based, admin-confirmed):
 *   unpaid → payment_pending_verification → paid | payment_failed | refunded
 *
 * Note: 'failed' is retained as a backward-compat alias in the enum.
 */

import mongoose from "mongoose";
import { randomUUID } from "crypto";

const orderSchema = new mongoose.Schema({
  tenantId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Tenant",
    required: true,
    index: true,
  },

  businessId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "BusinessConfig",
    index: true,
  },

  customerPhone: { type: String, required: true, index: true },
  phone:         { type: String, index: true }, // legacy alias

  // Auto-generated UUID per order — ensures the unique (tenantId, customerPhone, idempotencyKey)
  // index is always satisfied. Prevents duplicate orders from button double-taps.
  idempotencyKey: {
    type:    String,
    default: () => randomUUID(),
  },

  item:     { type: String, required: true },
  quantity: { type: Number, required: true, min: 1 },

  // [FIX-I] addOns was written by orderService.saveOrder() and orderFlow.js
  // (data.addOns) but was absent from the schema — Mongoose strict mode silently
  // dropped every write. Upsell add-on names were never persisted to the order record.
  addOns: { type: [String], default: [] },

  totalPrice: { type: Number, default: null },

  status: {
    type: String,
    enum: ["pending", "payment_pending_verification", "confirmed", "completed", "cancelled", "rejected", "payment_failed"],
    default: "pending",
    index: true,
  },

  // ── Payment fields — supports multi-channel screenshot-based verification ───
  paymentMethod: {
    type: String,
    // Supported channels: customer sends screenshot, admin confirms manually.
    // "wave" kept as canonical value; new channels added alongside it.
    enum: ["wave", "gt_bank", "ecobank", "trust_bank", "cash", "card", "other", null],
    default: null,
  },

  paymentStatus: {
    type: String,
    // Keep ALL values that are written anywhere in the codebase.
    // Mongoose strict mode silently drops $set operations that use a value
    // not in this enum — which breaks every payment state transition.
    //   proof_received      — paymentService.receiveProof (customer sent screenshot)
    //   self_confirmed      — paymentService.handleDonePayment (requireProof=false)
    //   confirmed           — adminCommandService.confirmPayment (admin approved)
    //   rejected            — adminCommandService.rejectPayment (admin rejected)
    //   payment_failed      — canonical failure status
    //   failed              — backward-compat alias; do not remove
    //   cancelled           — set when customer cancels at PAYMENT_PROOF step
    //                         (webhookController step 10.5). Without this value
    //                         Mongoose strict mode silently drops the $set and
    //                         the order stays 'unpaid', causing the scheduler to
    //                         send payment reminders for cancelled orders.
    enum: [
      'unpaid',
      'proof_received',
      'payment_pending_verification',
      'self_confirmed',
      'confirmed',
      'paid',
      'rejected',
      'payment_failed',
      'failed',
      'refunded',
      'cancelled',
      null,
    ],
    default: 'unpaid',
  },

  // URL or WhatsApp media ID of the payment screenshot the customer sends
  paymentProof: {
    type: String,
    default: null,
  },

  // Timestamps for payment lifecycle
  paymentInitiatedAt: { type: Date, default: null },
  proofReceivedAt:    { type: Date, default: null },

  // Who reviewed the payment and when (set by admin confirm/reject)
  paymentReviewedBy: { type: String, default: null },
  paymentReviewedAt: { type: Date,   default: null },

  // Legacy aliases (ordersController uses verifiedBy/verifiedAt)
  verifiedBy:   { type: String, default: null },
  verifiedAt:   { type: Date,   default: null },
  rejectedNote: { type: String, default: null },

  // Free-text notes — editable via PATCH /business/orders/:id
  notes: { type: String, default: null },

  // [FIX] Stored payment reference (DSB-MMDD-XXXX) generated at initiation time.
  // paymentService.initiatePayment() writes this so the reference never drifts
  // between the initial instructions and any follow-up messages. Without this
  // field in the schema, Mongoose strict mode silently drops the $set and the
  // stored reference is always null — falling back to a freshly-generated ref
  // that may differ from the one already shown to the customer.
  paymentReference: { type: String, default: null },

  // [FIX] Set by schedulerService when a payment-reminder WhatsApp template is sent.
  // Acts as an idempotency flag — without this in the schema, Mongoose strict
  // mode drops the $set, causing the scheduler to re-message every run.
  paymentReminderSentAt: { type: Date, default: null },

  // Set by schedulerService when an abandoned-cart WhatsApp template is sent.
  // Acts as an idempotency flag — without this in the schema, Mongoose strict
  // mode drops the $set, causing the scheduler to re-message the same customer
  // on every run.
  abandonedCartAt: { type: Date, default: null },

  // Last 6 hex chars of _id, stored at creation time for O(1) admin lookups.
  // Admin commands like "APPROVE ABC123" resolve against this field via an index
  // instead of an unindexed $expr/$regexMatch scan on the ObjectId string.
  shortId: { type: String, index: true, default: null },

}, { timestamps: true });

// Compound index for admin queries: all pending-verification orders per tenant
orderSchema.index({ tenantId: 1, paymentStatus: 1, createdAt: -1 });

// Idempotency index — must be unique so duplicate button taps don't create double orders.
// The default: randomUUID() on the field means this is always populated and always unique.
orderSchema.index({ tenantId: 1, customerPhone: 1, idempotencyKey: 1 }, { unique: true });

// Compound index for fast admin commands: "APPROVE <shortId>" / "REJECT <shortId>".
// Covers the (tenantId, paymentStatus, shortId) triple used in adminPaymentHandler.
orderSchema.index({ tenantId: 1, paymentStatus: 1, shortId: 1 });

// Populate shortId (last 6 hex chars of _id) before the first save so admin commands
// like "APPROVE ABC123" can resolve via a simple indexed findOne({ shortId }) instead
// of an unindexed $expr/$regexMatch scan across the _id string.
orderSchema.pre('save', function (next) {
  if (!this.shortId) {
    this.shortId = String(this._id).slice(-6).toUpperCase();
  }
  next();
});

// [FIX-8] pre('save') does not fire on insertMany(). Add a pre('insertMany') hook as
// a defensive measure so bulk-created orders still get shortIds. Currently no code
// path calls Order.insertMany(), but this prevents a future silent shortId=null bug
// if bulk creation is ever added (e.g. import tooling, seed scripts, migration jobs).
orderSchema.pre('insertMany', function (next, docs) {
  if (Array.isArray(docs)) {
    for (const doc of docs) {
      if (!doc.shortId && doc._id) {
        doc.shortId = String(doc._id).slice(-6).toUpperCase();
      }
    }
  }
  next();
});

export default mongoose.model("Order", orderSchema);
