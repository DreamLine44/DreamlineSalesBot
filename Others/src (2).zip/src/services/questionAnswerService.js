/**
 * questionAnswerService.js
 *
 * DB-first Q&A layer for Ask a Question mode.
 * Retrieves real business data before falling back to Groq AI.
 */

import { formatMoney } from '../utils/formatCurrency.js';
import { cartTotal, cartItemCount, formatCartSummary } from '../core/shared/cartEngine.js';
import { findBestMatch } from '../utils/matchEngine.js';
import { normalizeHoursDays } from '../utils/businessHoursUtils.js';
import { getAIReply } from '../core/ai/providers/aiRouter.js';
import { getAiHistoryMessages, buildConversationContext } from '../core/nlu/nluContext.js';
import {
  extractShortId,
  lookupActivityByReference,
  recoverRecentActivities,
  formatLookupFailureMessage,
  isValidShortIdFormat,
} from './activityLookupService.js';
import {
  formatOrderStatusCard,
  formatBookingStatusCard,
  detectStatusScope,
  buildStatusReply,
} from './activityStatusService.js';
import {
  isBusinessScopeQuestion,
  mergeQuestionContext,
  buildQuestionContextBlock,
  isInformationalActivityQuestion,
  isGreetingMessage,
} from './questionModeHelper.js';
import { getModeConfig } from '../config/modes.js';

// Includes conversational references to the menu just shown. Customers naturally
// ask "are these the only ones you have?" instead of repeating the word "menu".
// Resolve those against the real catalog rather than making the AI infer availability.
const MENU_RE = /\b(menu|what do you (have|serve|sell|offer)|today'?s menu|show menu|view menu|see menu|what('s| is) (on|in) (the )?menu|list (of )?(food|items|products|dishes|services)|price list|catalog|available (food|items|products|dishes|services)|are (these|those) (all|the only)( ones)? (you have|available|there is)|is (that|this) all (you have|that is available)|anything else (available|on the menu)|what else do you have)\b/i;
// [FIX-HOURS-NATURAL] Customers rarely say "opening hours" — they ask "are
// you open on sundays?", "what days are you open", or just "you open?". The
// old pattern only matched "are you open" (no day) and "open/close today",
// so day-specific and terse phrasing fell through to GENERAL.
const HOURS_RE = /\b(hours|opening hours|business hours|when do you (open|close)|what time do you (open|close|close today|open today)|are you open|you open\b|closing time|opening time|open today|close today|open (on |every )?(mon|tues?|wednes|thurs?|fri|satur|sun)\w*days?|open (on )?weekends?|what days are you open|which days are you open|do you open on)\b/i;
// [FIX-PRICE-PLURAL] \bprice\b / \bcost\b never matched the far more common
// plural phrasing "what are the prices of your food items" / "what are the
// costs" — the word-boundary after "price"/"cost" fails when an "s" follows
// with no boundary in between, so classifyQuestion() fell through to
// 'GENERAL' for exactly the plural questions customers actually ask, and the
// message went to the ORDER-phrase detectors instead of this PRICE handler.
const PRICE_RE = /\b(how much|prices?|costs?|what does .+ cost)\b/i;
const AVAILABILITY_RE = /\b(do you have|is there|is .+ available|available)\b/i;
const STATUS_RE = /\b(track|status|where is my|check my|my order|my booking|my appointment|order update|booking update)\b/i;
const ADDRESS_RE = /\b(address|location|where are you|find you|directions|located)\b/i;
// [FIX-CONTACT-NATURAL] "how do I reach you" / "get in touch" / "your whatsapp"
// are common ways customers ask for contact info without saying "phone" or
// "contact number" verbatim.
const CONTACT_RE = /\b(phone|phone number|telephone|call|contact number|whatsapp number|(your|ur) whatsapp|reach you|get in touch|get a hold of you|email|e-mail)\b/i;
// [FIX-PAYMENT-NATURAL] "do you accept card payments" / "credit card" never
// matched because the old pattern required the bare words "payment"/"pay"/
// "wave"/"cash"/"mobile money" — "accept ... card" phrasing fell through.
const PAYMENT_RE = /\b(payment|pay|wave|cash|mobile money|how (can|do) i pay|accept (cards?|visa|mastercard|credit|debit)|credit card|debit card|card payment)\b/i;
const BOOKING_INFO_RE = /\b(what (?:can|could|do|should) (?:i|we) (?:book|reserve)|what (?:do you|can you) offer (?:for )?(?:booking|reservation)|what (?:services?|tables?) (?:can|do) (?:i|you) book|how does booking work)\b/i;
const ABOUT_RE = /\b(what is this (?:all )?about|what are you|who are you|tell me about (?:you|your business|this place))\b/i;

function formatHourDecimal(h) {
  if (h == null || h === '') return null;
  const n = Number(h);
  if (!Number.isFinite(n)) return String(h);
  const hrs = Math.floor(n);
  const mins = Math.round((n - hrs) * 60);
  const suffix = hrs >= 12 ? 'PM' : 'AM';
  const h12 = hrs % 12 || 12;
  return mins ? `${h12}:${String(mins).padStart(2, '0')} ${suffix}` : `${h12} ${suffix}`;
}

/** Format menu items / services as WhatsApp-friendly text. */
export function formatMenuText(business, { maxItems = 30, heading = null } = {}) {
  const mode = (business?.businessMode || 'RETAIL').toUpperCase();
  const isSalon = mode === 'SALON' || mode === 'BARBERSHOP';
  const currency = business?.payment?.currency || 'GMD';

  const menuItems = (business?.menuItems || []).filter(i => i.available !== false);
  const services = (business?.services || []).filter(s => s.available !== false);

  const items = isSalon && services.length
    ? services.map(s => ({ name: s.name, price: s.price, emoji: '💇' }))
    : menuItems.map(i => ({ name: i.name, price: i.price, emoji: '🍽️' }));

  if (!items.length) {
    return 'Our menu is being updated. Please contact us directly for current availability.';
  }

  const shown = items.slice(0, maxItems);
  const lines = shown.map(i => {
    const priceStr = i.price != null ? ` — ${currency}${formatMoney(i.price)}` : '';
    return `${i.emoji} *${i.name}*${priceStr}`;
  });

  const title = heading || (isSalon ? '💇 Our Services' : '🍽️ Today\'s Menu');
  let body = `${title}\n\n${lines.join('\n')}`;
  if (items.length > maxItems) {
    body += `\n\n_...and ${items.length - maxItems} more._`;
  }
  return body;
}

export function formatHoursText(business) {
  const hours = business?.hours;
  if (!hours?.enabled) {
    return business?.adminPhone
      ? `Please contact us at 📞 *${business.adminPhone}* for our opening hours.`
      : 'Please contact us directly for our opening hours.';
  }

  const daysRaw = normalizeHoursDays(hours);
  const dayOrder = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
  const lines = [];

  for (const day of dayOrder) {
    const cfg = daysRaw[day];
    if (!cfg) continue;
    const label = day.charAt(0).toUpperCase() + day.slice(1);
    if (cfg.closed) {
      lines.push(`• *${label}:* Closed`);
    } else {
      const open = formatHourDecimal(cfg.open ?? hours.open);
      const close = formatHourDecimal(cfg.close ?? hours.close);
      if (open && close) lines.push(`• *${label}:* ${open} – ${close}`);
    }
  }

  if (!lines.length) {
    const open = formatHourDecimal(hours.open);
    const close = formatHourDecimal(hours.close);
    if (open && close) return `🕐 *Opening Hours*\n\n${open} – ${close}`;
    return 'Please contact us directly for our opening hours.';
  }

  return `🕐 *Opening Hours*\n\n${lines.join('\n')}`;
}

/** Explain what the customer can book/reserve at this business. */
export function formatBookingInfoText(business) {
  const cfg = getModeConfig(business);
  const hasBooking = (cfg?.flows || []).includes('BOOKING');
  const currency = business?.payment?.currency || 'GMD';
  const services = (business?.services || []).filter(s => s.available !== false);

  if (!hasBooking) {
    return "We don't take advance bookings online — but you can place an order anytime! Ask me about our menu or hours.";
  }

  if (services.length) {
    const lines = services.slice(0, 20).map(s => {
      const priceStr = s.price != null ? ` — ${currency}${formatMoney(s.price)}` : '';
      return `• *${s.name}*${priceStr}`;
    });
    let body = `📅 *What you can book:*\n\n${lines.join('\n')}`;
    if (services.length > 20) body += `\n\n_...and ${services.length - 20} more._`;
    body += `\n\nWhen you're ready, say *book a table* or tap *📅 Book a Table* from the menu.`;
    return body;
  }

  const mode = (business?.businessMode || 'RESTAURANT').toUpperCase();
  if (mode === 'RESTAURANT' || mode === 'BAKERY' || mode === 'DELIVERY') {
    return '📅 You can *book a table* with us — pick your date, time, and party size.\n\nWhen you\'re ready, tap *📅 Book a Table* from the menu.';
  }
  if (mode === 'SALON' || mode === 'BARBERSHOP') {
    return formatMenuText(business, { heading: '💇 Services you can book', maxItems: 20 });
  }
  return '📅 You can make a booking with us. Tap *📅 Book* from the menu when you\'re ready.';
}

function formatAboutText(business) {
  const name = business?.name || 'Our business';
  const desc = String(business?.description || '').trim();
  const mode = (business?.businessMode || 'RETAIL').toUpperCase();
  const cfg = getModeConfig(business);
  const flows = cfg?.flows || [];

  const offers = [];
  if (flows.includes('ORDER')) offers.push('order food/products');
  if (flows.includes('BOOKING')) offers.push('book a table or appointment');
  if (flows.includes('ENQUIRY') || flows.includes('QUESTION')) offers.push('ask questions');

  let body = desc
    ? `*${name}*\n\n${desc}`
    : `*${name}* is a ${mode.toLowerCase().replace(/_/g, ' ')} business here on WhatsApp.`;

  if (offers.length) {
    body += `\n\nI can help you ${offers.join(', ')}. What would you like to know?`;
  } else {
    body += '\n\nWhat would you like to know?';
  }
  return body;
}

function tryFaqMatch(message, business) {
  const raw = String(message || '').trim().toLowerCase();
  const faqs = business?.faq || [];
  for (const faq of faqs) {
    const trigger = String(faq.trigger || '').trim().toLowerCase();
    if (!trigger || trigger.length < 2) continue;
    const re = new RegExp(`\\b${trigger.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
    if (re.test(raw)) return faq.reply;
  }
  return null;
}

function classifyQuestion(message, session, business) {
  const raw = String(message || '').trim();
  const ctx = session?.data?._questionCtx || {};

  if (extractShortId(raw, session) || STATUS_RE.test(raw)) return 'STATUS';
  if (ctx.lastTopic === 'ORDER_TRACKING' && /\b(deleted|removed|cancelled|canceled|missing|gone|lost|where|what happened)\b/i.test(raw)) {
    return 'STATUS';
  }
  if (CONTACT_RE.test(raw)) return 'CONTACT';
  if (ABOUT_RE.test(raw)) return 'ABOUT';
  if (BOOKING_INFO_RE.test(raw) || (/\bwhat\b/i.test(raw) && /\bbook\b/i.test(raw) && isInformationalActivityQuestion(raw))) {
    return 'BOOKING_INFO';
  }
  if (AVAILABILITY_RE.test(raw) && !MENU_RE.test(raw)) return 'AVAILABILITY';
  if (MENU_RE.test(raw)) return 'MENU';
  if (HOURS_RE.test(raw)) return 'HOURS';
  if (PRICE_RE.test(raw)) return 'PRICE';
  if (ADDRESS_RE.test(raw)) return 'ADDRESS';
  if (PAYMENT_RE.test(raw)) return 'PAYMENT';
  if (tryFaqMatch(raw, business)) return 'FAQ';
  return 'GENERAL';
}

async function answerStatusQuestion({ message, business, session }) {
  const phone = session.customerPhone;
  const tenantId = session.tenantId;
  const scope = detectStatusScope(message);
  const ctx = session?.data?._questionCtx || {};
  const ref = extractShortId(message, session) || ctx.lastReference || null;
  const adminPhone = business?.adminPhone;

  if (ref && isValidShortIdFormat(ref)) {
    const { order, booking, checks } = await lookupActivityByReference({
      shortId: ref,
      tenantId,
      customerPhone: phone,
      scope,
    });

    if (order && (scope === 'ORDER' || scope === 'BOTH')) {
      if (phone && order.customerPhone && order.customerPhone !== phone) {
        return {
          body: `Order *#${ref}* exists but may belong to a different number. Please contact us for help.${adminPhone ? `\n\n📞 *${adminPhone}*` : ''}`,
          context: { lastReference: ref, lastTopic: 'ORDER_TRACKING', lastMessage: message },
        };
      }
      return {
        body: formatOrderStatusCard(order, business),
        context: { lastReference: ref, lastTopic: 'ORDER_TRACKING', lastMessage: message },
      };
    }

    if (booking && (scope === 'BOOKING' || scope === 'BOTH')) {
      if (phone && booking.customerPhone && booking.customerPhone !== phone) {
        return {
          body: `Booking *#${ref}* exists but may belong to a different number. Please contact us for help.${adminPhone ? `\n\n📞 *${adminPhone}*` : ''}`,
          context: { lastReference: ref, lastTopic: 'BOOKING_TRACKING', lastMessage: message },
        };
      }
      return {
        body: formatBookingStatusCard(booking, business),
        context: { lastReference: ref, lastTopic: 'BOOKING_TRACKING', lastMessage: message },
      };
    }

    const recovery = await recoverRecentActivities({ customerPhone: phone, tenantId, scope });
    const allChecks = [...checks, ...recovery.checks];
    return {
      body: formatLookupFailureMessage({ shortId: ref, checks: allChecks, adminPhone }),
      context: { lastTopic: 'ORDER_TRACKING', lastMessage: message },
      stayOnTopic: true,
    };
  }

  // Follow-up without explicit ref but prior tracking context
  if (ctx.lastReference && /\b(deleted|removed|cancelled|canceled|missing|gone|lost|what happened|still)\b/i.test(message)) {
    return answerStatusQuestion({
      message: `#${ctx.lastReference} ${message}`,
      business,
      session,
    });
  }

  return null;
}

/**
 * Try to answer from database/templates before calling Groq.
 * @returns {{ handled: boolean, body?: string, routingDecision?: string, context?: object, stayOnTopic?: boolean }}
 */
export async function tryDatabaseAnswer({ message, business, session }) {
  const raw = String(message || '').trim();
  if (!raw) return { handled: false };

  const faqAnswer = tryFaqMatch(raw, business);
  if (faqAnswer) {
    return { handled: true, body: faqAnswer, routingDecision: 'FAQ', context: { lastMessage: raw, lastTopic: 'FAQ' } };
  }

  const qType = classifyQuestion(raw, session, business);

  if (qType === 'STATUS') {
    const statusAnswer = await answerStatusQuestion({ message: raw, business, session });
    if (statusAnswer) {
      return { handled: true, routingDecision: 'TRACK_ORDER', ...statusAnswer };
    }
    // Ref-less status ("where is my order") — delegate to phone-scoped DB lookup.
    try {
      const statusReply = await buildStatusReply({ session, business, message: raw });
      const body = typeof statusReply === 'string' ? statusReply : statusReply?.body;
      if (body) {
        return {
          handled: true,
          routingDecision: 'TRACK_ORDER',
          body,
          context: { lastMessage: raw, lastTopic: 'ORDER_TRACKING' },
          stayOnTopic: true,
        };
      }
    } catch { /* fall through to AI */ }
  }

  if (qType === 'ABOUT') {
    return {
      handled: true,
      body: formatAboutText(business),
      routingDecision: 'QUESTION',
      context: { lastMessage: raw, lastTopic: 'ABOUT' },
    };
  }

  if (qType === 'BOOKING_INFO') {
    return {
      handled: true,
      body: formatBookingInfoText(business),
      routingDecision: 'QUESTION',
      context: { lastMessage: raw, lastTopic: 'BOOKING' },
    };
  }

  if (qType === 'MENU') {
    const { shouldShowCatalogButton } = await import('../modules/catalog/waCatalogConfig.js');
    if (shouldShowCatalogButton(business)) {
      return {
        handled: true,
        showCatalog: true,
        routingDecision: 'BROWSE_CATALOG',
        context: { lastMessage: raw, lastTopic: 'MENU' },
      };
    }
    const menuText = formatMenuText(business);
    return {
      handled: true,
      body: menuText,
      routingDecision: 'VIEW_MENU',
      context: { lastMessage: raw, lastTopic: 'MENU' },
    };
  }

  if (qType === 'AVAILABILITY') {
    const menu = [
      ...(business?.menuItems || []).filter(i => i.available !== false),
      ...(business?.services || []).filter(s => s.available !== false),
    ];
    const query = raw
      .toLowerCase()
      .replace(/[^\p{L}\p{N}\s]/gu, ' ')
      .replace(/\b(do you have|is there|is|are there|are|available|any)\b/gi, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    const candidates = menu.filter(item => {
      const itemName = String(item.name || '').toLowerCase();
      return query.split(/\s+/).some(token => token.length > 2 && itemName.includes(token));
    });
    if (candidates.length === 1) {
      return { handled: true, body: `✅ Yes, *${candidates[0].name}* is currently available.`, routingDecision: 'QUESTION', context: { lastMessage: raw, lastTopic: 'AVAILABILITY' } };
    }
    if (candidates.length > 1) {
      return { handled: true, body: `Which item do you mean — ${candidates.slice(0, 4).map(item => `*${item.name}*`).join(', ')}?`, routingDecision: 'QUESTION', context: { lastMessage: raw, lastTopic: 'AVAILABILITY' } };
    }
    return { handled: true, body: `I couldn't find that item on the current menu.`, routingDecision: 'QUESTION', context: { lastMessage: raw, lastTopic: 'AVAILABILITY' } };
  }

  if (qType === 'HOURS') {
    return {
      handled: true,
      body: formatHoursText(business),
      routingDecision: 'QUESTION',
      context: { lastMessage: raw, lastTopic: 'HOURS' },
    };
  }

  if (qType === 'PRICE') {
    const menu = [
      ...(business?.menuItems || []).filter(i => i.available !== false),
      ...(business?.services || []).filter(s => s.available !== false).map(s => ({ ...s, name: s.name })),
    ];
    const priceStopWords = ['how', 'much', 'does', 'cost', 'costs', 'price', 'prices', 'the', 'your', 'for', 'and', 'are', 'what'];
    const queryWords = raw.toLowerCase().split(/\s+/).filter(word => word.length > 2 && !priceStopWords.includes(word));
    const candidates = menu.filter(item => queryWords.some(word => String(item.name || '').toLowerCase().includes(word)));
    if (candidates.length > 1) {
      return { handled: true, body: `Which one do you mean — ${candidates.slice(0, 4).map(item => `*${item.name}*`).join(', ')}?`, routingDecision: 'QUESTION', context: { lastMessage: raw, lastTopic: 'PRICE' } };
    }
    const { item, confidenceLevel } = findBestMatch(menu, raw);
    if (item && confidenceLevel === 'HIGH') {
      const currency = business?.payment?.currency || 'GMD';
      const priceStr = item.price != null ? `${currency}${formatMoney(item.price)}` : 'contact us for pricing';
      return {
        handled: true,
        body: `💰 *${item.name}* — ${priceStr}`,
        routingDecision: 'QUESTION',
        context: { lastMessage: raw, lastTopic: 'PRICE' },
      };
    }
    // [FIX-PRICE-GENERAL] A price question that doesn't name a specific item
    // ("what are the prices of your food items", "how much is everything")
    // has no single item to match against, so candidates is empty and
    // findBestMatch never reaches HIGH confidence. This used to fall all the
    // way through the function to `{ handled: false }`, handing a plain
    // price question to the ORDER-phrase detectors upstream (which then
    // tried to parse it as a product name and reported a catalogue miss —
    // see [FIX-QUESTION-VS-ORDER] in intentEngine.js/webhookController.js).
    // The business's own priced menu answers this directly, so show it
    // instead of reporting a dead end.
    if (menu.length) {
      const menuText = formatMenuText(business, { heading: '💰 Prices' });
      return {
        handled: true,
        body: `${menuText}\n\n_Ask about a specific item for its exact price._`,
        routingDecision: 'QUESTION',
        context: { lastMessage: raw, lastTopic: 'PRICE' },
      };
    }
  }

  if (qType === 'ADDRESS' || qType === 'CONTACT') {
    const addr = business?.address;
    const phone = business?.adminPhone || business?.phone || business?.contactPhone;
    const email = business?.email || business?.contactEmail;
    const parts = [];
    if (qType === 'ADDRESS' && addr) parts.push(`📍 *Location*\n\n${addr}`);
    if (phone) parts.push(`📞 *${phone}*`);
    if (email) parts.push(`✉️ *${email}*`);
    if (parts.length) return { handled: true, body: parts.join('\n\n'), routingDecision: 'QUESTION', context: { lastMessage: raw, lastTopic: qType } };
  }

  if (/\b(total|how much is everything|cart total|what is my total)\b/i.test(raw)) {
    const cart = Array.isArray(session?.data?.cart) ? session.data.cart : [];
    const total = cartTotal(cart);
    if (cart.length && total != null) {
      const currency = business?.payment?.currency || 'GMD';
      return { handled: true, body: `🧾 *Your cart*\n\n${formatCartSummary(cart, business)}\n\nItems: ${cartItemCount(cart)}\nTotal: ${currency}${formatMoney(total)}`, routingDecision: 'QUESTION', context: { lastMessage: raw, lastTopic: 'CART' } };
    }
  }

  if (qType === 'ADDRESS') {
    const addr = business?.address;
    const phone = business?.adminPhone;
    if (addr || phone) {
      let body = '📍 *Location*\n\n';
      if (addr) body += addr;
      if (phone) body += `${addr ? '\n\n' : ''}📞 *${phone}*`;
      return { handled: true, body, routingDecision: 'QUESTION', context: { lastMessage: raw, lastTopic: 'ADDRESS' } };
    }
  }

  if (qType === 'PAYMENT') {
    const channels = business?.payment?.channels || [];
    if (channels.length) {
      return {
        handled: true,
        body: `💳 *Payment Methods*\n\nWe accept: ${channels.join(', ')}`,
        routingDecision: 'QUESTION',
        context: { lastMessage: raw, lastTopic: 'PAYMENT' },
      };
    }
  }

  return { handled: false };
}

/**
 * Process a question-mode message: DB-first, then AI fallback.
 *
 * Question Mode is answer-only: no buttons are ever attached here. The
 * customer stays in Q&A and can ask another question freely; switching to
 * another activity (ordering, booking, etc.) is detected upstream from their
 * own words (see webhookController's mid-flow switch detector /
 * _detectMidFlowSwitchRequest) rather than offered as a tap target after
 * every answer.
 */
export async function processQuestionMessage({ session, message, business, tenant, intent = 'FAQ' }) {
  const raw = String(message || '').trim();

  if (isGreetingMessage(raw)) {
    const cfg = getModeConfig(business);
    const { buildWelcomeSequence } = await import('../core/conversations/moduleRouter.js');
    return {
      type: 'welcome_sequence',
      sequence: buildWelcomeSequence(business, cfg),
      exitQuestionMode: true,
    };
  }

  if (!isBusinessScopeQuestion(raw, business)) {
    return {
      type: 'text',
      body: "I'm here to help with questions about our business — menu, services, hours, orders, and bookings. What would you like to know?",
      context: mergeQuestionContext(session, { lastMessage: raw }),
    };
  }

  const dbAnswer = await tryDatabaseAnswer({ message: raw, business, session });
  if (dbAnswer.handled) {
    if (dbAnswer.showCatalog) {
      const { tryShowCatalogForMenuRequest } = await import('../modules/catalog/waCatalogFlow.js');
      const catalogResult = await tryShowCatalogForMenuRequest({
        message: raw, session, business, tenant,
      });
      if (catalogResult?.handled) {
        return {
          type: 'catalog',
          catalogDispatched: !catalogResult.reply,
          ...(catalogResult.reply || {}),
          context: mergeQuestionContext(session, dbAnswer.context || { lastMessage: raw }),
        };
      }
    }
    if (dbAnswer.body) {
      return {
        type: 'text',
        body: dbAnswer.body,
        context: mergeQuestionContext(session, dbAnswer.context || { lastMessage: raw }),
      };
    }
  }

  // Natural menu/food browse outside strict DB MENU classification.
  const { tryShowCatalogForMenuRequest } = await import('../modules/catalog/waCatalogFlow.js');
  const catalogResult = await tryShowCatalogForMenuRequest({
    message: raw, session, business, tenant,
  });
  if (catalogResult?.handled) {
    return {
      type: 'catalog',
      catalogDispatched: !catalogResult.reply,
      ...(catalogResult.reply || {}),
      context: mergeQuestionContext(session, { lastMessage: raw, lastTopic: 'MENU' }),
    };
  }

  const ctxBlock = buildQuestionContextBlock(session);
  const aiReply = await getAIReply({
    customerMessage: raw,
    business,
    session,
    intent,
    history: getAiHistoryMessages(session),
    sessionContext: [buildConversationContext({ session, business }), ctxBlock].filter(Boolean).join('\n'),
  });

  return {
    type: 'text',
    body: aiReply || "Great question! Please contact us directly and we'll be happy to help.",
    context: mergeQuestionContext(session, { lastMessage: raw, lastTopic: 'GENERAL' }),
  };
}

/** Persist question-mode session state (stay in Q&A). Preserves ENQUIRY vs QUESTION flow. */
export async function persistQuestionSession(session, tenant, context = {}) {
  const { updateSession } = await import('../core/sessions/sessionService.js');
  const flow = session?.currentFlow === 'ENQUIRY' ? 'ENQUIRY' : 'QUESTION';
  const data = {
    ...(session.data || {}),
    _questionCtx: mergeQuestionContext(session, context),
  };
  await updateSession(session.customerPhone, session.tenantId, {
    currentFlow: flow,
    step: 'AWAITING_QUESTION',
    data,
  });
  return { ...session, currentFlow: flow, step: 'AWAITING_QUESTION', data };
}

/** Append user/bot turns to aiHistory for Q&A paths (mirrors webhook step 17). */
export async function recordQuestionHistory(session, userMessage, botPayload) {
  const { updateSession } = await import('../core/sessions/sessionService.js');
  const { appendAiHistoryTurn, extractReplyText } = await import('../core/nlu/nluContext.js');
  let aiHistory = appendAiHistoryTurn(session, 'user', userMessage);
  const botText = extractReplyText(botPayload);
  if (botText) aiHistory = appendAiHistoryTurn({ aiHistory }, 'assistant', botText);
  await updateSession(session.customerPhone, session.tenantId, { aiHistory }).catch(() => {});
  return { ...session, aiHistory };
}

/**
 * Unified Q&A handler for all mode-specific QUESTION flows and generic ENQUIRY.
 * DB-first status/menu/hours, then AI fallback. Returns WhatsApp payload.
 */
export function toWhatsAppPayload(reply) {
  if (!reply || reply.catalogDispatched) return null;
  if (reply.type === 'welcome_sequence') return null;
  if (reply.type && reply.type !== 'text') {
    const { context, catalogDispatched, exitQuestionMode, sequence, ...payload } = reply;
    return payload;
  }
  if (reply.body) {
    return { type: reply.type || 'text', body: reply.body, buttons: reply.buttons };
  }
  return null;
}

/**
 * Normalize a resolveQuestionReply result for flow handlers.
 * Returns a single payload, an array (welcome menu), or null (catalog already sent).
 */
export async function finalizeQuestionHandlerReply({ session, tenant, reply }) {
  if (reply?.type === 'welcome_sequence' && Array.isArray(reply.sequence)) {
    const { updateSession } = await import('../core/sessions/sessionService.js');
    await updateSession(session.customerPhone, session.tenantId, {
      currentFlow: null, step: null, postFlowAck: null, postFlowData: null,
    }).catch(() => {});
    return reply.sequence;
  }
  return toWhatsAppPayload(reply) || { type: 'text', body: '' };
}

export async function resolveQuestionReply({ session, message, business, tenant, intent = 'FAQ', initPayload = null }) {
  const raw = String(message || '').trim();

  if (!raw || raw.length < 2) {
    return initPayload || {
      type: 'text',
      body: '❓ What would you like to know? Ask about our menu, hours, orders, or bookings.',
    };
  }

  return processQuestionMessage({ session, message: raw, business, tenant, intent });
}
