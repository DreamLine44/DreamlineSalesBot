// src/features/menuImage.js
// Feature: Menu Image
// Consolidates controller and service logic for menu image handling.

import MenuImage from '../models/MenuImage.js';
import logger from '../config/logger.js';

export async function uploadMenuImage(req, res) {
  // TODO: implement
}

export async function getMenuImage(req, res) {
  // TODO: implement
}

export default {
  uploadMenuImage,
  getMenuImage,
};