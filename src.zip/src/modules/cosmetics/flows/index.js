/**
 * modules/cosmetics/flows/index.js
 * Cosmetics module — products + skin profile + AI beauty recommendations + consultations
 */
import { updateSession }     from '../../../core/sessions/sessionService.js';
import { completeFlow }      from '../../../core/conversations/flowEngine.js';
import { handleBookingFlow } from '../../../core/conversations/bookingFlow.js';
import { getAIReply }        from '../../../core/ai/providers/aiRouter.js';
import { findBestMatch }     from '../../../utils/matchEngine.js';
import { saveOrder }         from '../../../services/orderService.js';
import logger                from '../../../config/logger.js';

export const COSMETICS_CONFIG = {
  businessMode: 'COSMETICS',
  flows: ['ORDER', 'BOOKING'],
  persona: 'knowledgeable beauty advisor who gives personalised skincare and makeup recommendations',
  steps: {
    ORDER:   ['SELECT_ITEM', 'QUANTITY', 'CONFIRM'],
    BOOKING: ['SELECT_SERVICE', 'DATE', 'DATE_CONFIRM', 'TIME', 'TIME_CONFIRM', 'CONFIRM'],
  },
  ui: {
    welcomeButtons: [
      { id: 'ORDER',    title: '💄 Shop Products'     },
      { id: 'BOOK',     title: '💅 Book Consultation' },
      { id: 'QUESTION', title: '❓ Beauty Advice'     },
    ],
    fallbackButtons: [
      { id: 'ORDER',    title: '💄 Shop'    },
      { id: 'BOOK',     title: '💅 Consult' },
      { id: 'QUESTION', title: '❓ Advice'  },
    ],
    confirmButtons: [{ id: 'CONFIRM', title: '✅ Confirm Order' }, { id: 'CANCEL', title: '❌ Cancel' }],
    upsellButtons:  [{ id: 'UPSELL_YES', title: '✅ Add it' }, { id: 'UPSELL_NO', title: '❌ No thanks' }],
  },
  messages: {
    welcome:   '💄 Welcome! Ready to glow? What can I help you find today?',
    cancelMsg: '✅ Cancelled! Come back anytime — we love helping you glow 💄',
    fallback:  'Would you like to *shop*, *book a consultation*, or get *beauty advice*?',
  },
};

export async function handleCosmeticsOrder({ session, message, business, tenant, isInteractive }) {
  const { handleOrderFlow } = await import('../../restaurant/flows/orderFlow.js');
  return handleOrderFlow({ session, message, business, tenant, isInteractive });
}

export async function handleCosmeticsBooking({ session, message, business, tenant, isInteractive }) {
  return handleBookingFlow({ session, message, business, tenant, isInteractive });
}

/** Skincare advice flow — AI-powered with skin type context */
export async function handleSkincareAdvice({ session, message, business, tenant }) {
  const raw  = String(message || '').trim();
  const step = session.step || 'SKIN_QUESTION';
  const data = session.data || {};

  // ── INIT ──────────────────────────────────────────────────────────────────
  if (message === null) {
    await updateSession(session.customerPhone, session.tenantId, { step: 'SKIN_QUESTION', data: {} });
    return {
      type: 'buttons',
      body: '💄 *Beauty Advice*\n\nWhat would you like help with today?',
      buttons: [
        { id: 'SKIN_DRY',    title: '💧 Dry Skin'    },
        { id: 'SKIN_OILY',   title: '✨ Oily Skin'   },
        { id: 'SKIN_COMBO',  title: '🌟 Combination' },
        { id: 'SKIN_CUSTOM', title: '💬 Describe it'  },
      ],
    };
  }

  // ── SKIN_QUESTION: customer picked a skin type button or typed their issue ─
  if (step === 'SKIN_QUESTION') {
    // [FIX] Map button IDs to human-readable skin type labels so AI gets
    // proper context instead of raw button IDs like "SKIN_DRY".
    const SKIN_TYPE_MAP = {
      'SKIN_DRY':   'dry',
      'SKIN_OILY':  'oily',
      'SKIN_COMBO': 'combination',
    };
    const mappedSkinType = SKIN_TYPE_MAP[raw.toUpperCase()] || null;
    const skinType = mappedSkinType || raw;

    // Store skin type and ask for the actual question
    await updateSession(session.customerPhone, session.tenantId, {
      step: 'SKIN_ADVICE',
      data: { ...data, skinType },
    });

    if (mappedSkinType) {
      // Button tap — ask for their specific concern
      return {
        type:    'buttons',
        body:    `Got it — *${skinType} skin* 💄\n\nWhat's your main concern? (e.g. acne, dark spots, moisturiser, routine)`,
        buttons: [{ id: 'SHOW_MENU', title: '🔄 Start Over' }],
      };
    }
    // They typed a description — treat it as their question immediately
    return await _buildSkincareAdvice(raw, skinType, business, session);
  }

  // ── SKIN_ADVICE: they described their concern — answer it ─────────────────
  return await _buildSkincareAdvice(raw, data.skinType || null, business, session);
}

async function _buildSkincareAdvice(question, skinType, business, session) {
  const skinContext = skinType ? `The customer has ${skinType} skin. ` : '';
  const prompt = `${skinContext}The customer asks: "${question}"\n\nAs a beauty advisor, recommend 1-2 specific products (from our range if mentioned) and briefly explain why. Keep it friendly and under 3 sentences.`;

  const aiReply = await getAIReply({ customerMessage: prompt, business, session, intent: 'SKINCARE_ADVICE' });
  return {
    type: 'buttons',
    body: aiReply || 'Great question! Let me suggest some products for you. 💄',
    buttons: [
      { id: 'ORDER',     title: '💄 Shop Now'         },
      { id: 'QUESTION',  title: '❓ Another Question'  },
      { id: 'SHOW_MENU', title: '🔄 Start Over' },
    ],
  };
}
