/**
 * controllers/businessController.js — WhatSalesAgent2
 *
 * [FIX-BIZ-1] All handlers now wrapped in try/catch — previously updateBusinessConfig,
 *             addMenuItem, and deleteMenuItem had no error handling; any DB or validation
 *             error threw an unhandled exception that crashed the response with a raw
 *             Mongoose stack trace instead of a clean 500 JSON response.
 * [FIX-BIZ-2] deleteMenuItem now matches by _id (not name) to be consistent with the
 *             dashboard CRUD and avoid accidental deletion of same-named items.
 *             The old route was DELETE /:tenantId/menu/:itemName — replaced with
 *             DELETE /:tenantId/menu/:itemId for precision.
 * [FIX-BIZ-3] updateBusinessConfig now strips protected fields (_id, tenantId, __v)
 *             AND rejects a completely empty body with a 400 instead of silently
 *             no-opping.
 * [AUDIT-FIX-17] getBusinessConfig now also returns a `tenantStatus` block sourced
 *             from req.tenant (attached by requireApiKey — see authMiddleware.js).
 *             Previously this endpoint ONLY returned the BusinessConfig document,
 *             which has no status/onboardingStep/whatsapp.connected fields — those
 *             live exclusively on the Tenant document, which no tenant-accessible
 *             route ever returned. The tenant dashboard was forced to *guess* setup
 *             progress from BusinessConfig.phoneNumberId alone (see frontend
 *             AuthContext.buildUserFromResponse), so an admin-onboarded tenant could
 *             never actually reach "Bot Activated" client-side even after the admin
 *             fully activated it server-side.
 *             req.tenant comes from a `.lean()` query, so Mongoose's toJSON
 *             transform (which strips accessToken/verifyToken/webhookSecret/
 *             apiKeyHash/meta.appSecret) does NOT run on it automatically — do not
 *             spread req.tenant directly into a response. Build tenantStatus as an
 *             explicit whitelist instead.
 */
import BusinessConfig from '../models/BusinessConfig.js';
import { getModeConfig, getSupportedModes } from '../config/modes.js';
import logger from '../config/logger.js';
import { uploadMenuImage, deleteMenuImage, CLOUDINARY_ENABLED } from '../config/cloudinary.js';
import { scheduleWaCatalogSync } from '../modules/catalog/waCatalogSyncScheduler.js';

// [AUDIT-FIX-17] Explicit whitelist — req.tenant is a lean object (no toJSON
// stripping), so never spread it wholesale into a tenant-facing response.
function safeTenantStatus(tenant) {
  if (!tenant) return null;
  return {
    status:         tenant.status,
    onboardingStep: tenant.onboardingStep,
    plan:           tenant.plan,
    whatsapp: {
      connected:      !!tenant.whatsapp?.connected,
      phone:          tenant.whatsapp?.phone || null,
      phoneNumberId:  tenant.whatsapp?.phoneNumberId || null,
      wabaId:         tenant.whatsapp?.wabaId || null,
      connectedAt:    tenant.whatsapp?.connectedAt || null,
      lastVerifiedAt: tenant.whatsapp?.lastVerifiedAt || null,
      // accessToken / verifyToken / webhookSecret intentionally omitted
    },
  };
}

export async function getBusinessConfig(req, res) {
  try {
    const { tenantId } = req.params;
    const biz = await BusinessConfig.findOne({ tenantId }).lean();
    if (!biz) return res.status(404).json({ error: 'Not found' });
    // [AUDIT-FIX-17] Super-admin callers hit this route with req.params.tenantId
    // but no req.tenant (that's only set for tenant-key auth) — tenantStatus will
    // be null in that case, which is fine; the admin UI reads /admin/tenants/:id.
    res.json({ business: biz, tenantStatus: safeTenantStatus(req.tenant) });
  } catch (err) {
    logger.error('[Business] getBusinessConfig failed', { err: err.message });
    res.status(500).json({ error: err.message });
  }
}

export async function updateBusinessConfig(req, res) {
  try {
    const { tenantId } = req.params;
    const update = { ...req.body };

    // [FIX-BIZ-1,3] Strip immutable fields and validate body
    delete update._id;
    delete update.tenantId;
    delete update.__v;
    // [FIX-BIZ-4] Strip phoneNumberId — it is the webhook routing key and must only
    // be changed via PATCH /admin/tenants/:id which syncs both Tenant and BusinessConfig
    // atomically. Allowing it to be overwritten here creates a split-brain where
    // Tenant.whatsapp.phoneNumberId and BusinessConfig.phoneNumberId diverge and
    // business-config lookups return stale data after the next credential update.
    delete update.phoneNumberId;

    // [FIX-MENU-ALIAS] Accept "menu" as an alias for "menuItems".
    // The API doc and Bruno collection use "menuItems", but a natural body key is "menu".
    // Mongoose strict mode silently drops "menu" since the schema field is "menuItems" —
    // the PUT appears to succeed (200 OK) but menuItems stays empty in the DB.
    if (update.menu !== undefined && update.menuItems === undefined) {
      update.menuItems = update.menu;
    }
    delete update.menu;

    // Same alias for services/faq common alternate key names
    if (update.servicesList !== undefined && update.services === undefined) {
      update.services = update.servicesList;
      delete update.servicesList;
    }

    // [CATALOG-BIZ-1] MongoDB's $set on a plain (non-dot-path) nested field
    // REPLACES the whole subdocument rather than merging it — Mongoose does
    // not expand sibling fields or reapply schema defaults on an update-path
    // $set. Since this is the only generic endpoint tenants use to configure
    // WA Catalog, sending `{ waCatalog: { catalogId: 'X' } }` as-is would
    // silently wipe an already-set enabled/mode, and vice versa. Flatten to
    // waCatalog.<key> dot-notation (mirroring the pre-existing [FIX-TONE-3]
    // pattern above) so each sub-field updates independently.
    if (update.waCatalog && typeof update.waCatalog === 'object') {
      for (const [k, v] of Object.entries(update.waCatalog)) {
        update[`waCatalog.${k}`] = v;
      }
      delete update.waCatalog;
    }

    if (!update || Object.keys(update).length === 0) {
      return res.status(400).json({ error: 'Request body is empty — nothing to update' });
    }

    // [FIX-TONE-3] findOneAndUpdate bypasses Mongoose pre('save') hooks, so the
    // tone-sync logic in businessConfigSchema.pre('save') never runs on update paths.
    // When businessMode is changing, compute and inline the tone fields here so they
    // stay consistent without requiring a separate save() round-trip.
    if (update.businessMode) {
      const toneMap = {
        RESTAURANT:  { style: 'FRIENDLY',     industry: 'RESTAURANT'  },
        BAKERY:      { style: 'FRIENDLY',     industry: 'BAKERY'      },
        RETAIL:      { style: 'PROFESSIONAL', industry: 'RETAIL'      },
        FASHION:     { style: 'PREMIUM',      industry: 'FASHION'     },
        ELECTRONICS: { style: 'PROFESSIONAL', industry: 'ELECTRONICS' },
        SALON:       { style: 'PROFESSIONAL', industry: 'SALON'       },
        BARBERSHOP:  { style: 'FRIENDLY',     industry: 'BARBERSHOP'  },
        COSMETICS:   { style: 'PREMIUM',      industry: 'COSMETICS'   },
        DELIVERY:    { style: 'FRIENDLY',     industry: 'DELIVERY'    },
        SERVICES:    { style: 'PROFESSIONAL', industry: 'SERVICES'    },
        GENERAL:     { style: 'FRIENDLY',     industry: 'GENERAL'     },
      };
      const t = toneMap[update.businessMode.toUpperCase()];
      if (t) {
        update['tone.style']    = t.style;
        update['tone.industry'] = t.industry;
      }
    }

    const biz = await BusinessConfig.findOneAndUpdate(
      { tenantId },
      { $set: update },
      { new: true, upsert: false, runValidators: true },
    ).lean();
    if (!biz) return res.status(404).json({ error: 'Not found' });
    // [CATALOG-AUTOSYNC-1] Only when this write actually touched menuItems —
    // not on every generic config edit (hours, tone, payment settings, etc.).
    if (update.menuItems !== undefined) scheduleWaCatalogSync(tenantId);
    res.json({ business: biz });
  } catch (err) {
    logger.error('[Business] updateBusinessConfig failed', { err: err.message });
    res.status(500).json({ error: err.message });
  }
}

export async function getMenu(req, res) {
  try {
    const { tenantId } = req.params;
    const biz = await BusinessConfig.findOne({ tenantId }).select('menuItems services').lean();
    if (!biz) return res.status(404).json({ error: 'Not found' });
    res.json({ menuItems: biz.menuItems || [], services: biz.services || [] });
  } catch (err) {
    logger.error('[Business] getMenu failed', { err: err.message });
    res.status(500).json({ error: err.message });
  }
}

export async function updateMenu(req, res) {
  try {
    const { tenantId } = req.params;
    // [FIX-MENU-ALIAS] Accept "menu" as alias for "menuItems"
    const menuItems = req.body.menuItems ?? req.body.menu;
    if (!Array.isArray(menuItems)) {
      return res.status(400).json({ error: 'menuItems (or menu) must be an array' });
    }
    const biz = await BusinessConfig.findOneAndUpdate(
      { tenantId },
      { $set: { menuItems } },
      { new: true },
    ).lean();
    if (!biz) return res.status(404).json({ error: 'Not found' });
    scheduleWaCatalogSync(tenantId);
    res.json({ menuItems: biz.menuItems });
  } catch (err) {
    logger.error('[Business] updateMenu failed', { err: err.message });
    res.status(500).json({ error: err.message });
  }
}

export async function addMenuItem(req, res) {
  try {
    const { tenantId } = req.params;
    const { name, price, description, available = true, showImageOnSelect = true } = req.body;

    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'name is required' });
    }

    // ── Parse array fields (keywords, tags) — arrive as strings from multipart ─
    let keywords = req.body.keywords ?? [];
    if (typeof keywords === 'string') {
      try { keywords = JSON.parse(keywords); } catch { keywords = keywords ? [keywords] : []; }
    }
    let tags = req.body.tags ?? [];
    if (typeof tags === 'string') {
      try { tags = JSON.parse(tags); } catch { tags = tags ? [tags] : []; }
    }

    // ── Cloudinary image upload (optional) ────────────────────────────────────
    let image = { url: null, public_id: null };
    if (req.file) {
      if (!CLOUDINARY_ENABLED) {
        return res.status(503).json({ error: 'Image uploads are not configured on this server.' });
      }
      try {
        const dataUri = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
        image = await uploadMenuImage(dataUri, { tenantId });
        logger.info('[Business] Menu image uploaded', { tenantId, public_id: image.public_id });
      } catch (uploadErr) {
        logger.error('[Business] Cloudinary upload failed', { err: uploadErr.message });
        return res.status(502).json({ error: `Image upload failed: ${uploadErr.message}` });
      }
    }

    const biz = await BusinessConfig.findOneAndUpdate(
      { tenantId },
      {
        $push: {
          menuItems: {
            name:             name.trim(),
            price:            Number(price) || 0,
            description,
            available:        available === 'false' ? false : Boolean(available),
            keywords,
            tags,
            showImageOnSelect: showImageOnSelect === 'false' ? false : Boolean(showImageOnSelect),
            image,
          },
        },
      },
      { new: true },
    );
    if (!biz) return res.status(404).json({ error: 'Not found' });
    scheduleWaCatalogSync(tenantId);
    res.status(201).json({ menuItems: biz.menuItems });
  } catch (err) {
    logger.error('[Business] addMenuItem failed', { err: err.message });
    res.status(500).json({ error: err.message });
  }
}

// [FIX-BIZ-2] Match by _id (not name) — precise, safe, consistent with dashboard CRUD
// [FIX #13]  Kept in sync with dashboardController.deleteMenuItem: both now check
//            modifiedCount so callers can detect a stale/wrong itemId.
// [FIX-BIZ-4] Cloudinary cleanup on delete — previously orphaned assets on Cloudinary
//             when a menu item with an image was deleted via this route.
export async function deleteMenuItem(req, res) {
  try {
    const { tenantId, itemId } = req.params;

    // Fetch image public_id BEFORE deleting so we can clean up Cloudinary
    const existing = await BusinessConfig.findOne(
      { tenantId, 'menuItems._id': itemId },
      { 'menuItems.$': 1 },
    ).lean();
    const imagePublicId = existing?.menuItems?.[0]?.image?.public_id;

    const result = await BusinessConfig.updateOne(
      { tenantId },
      { $pull: { menuItems: { _id: itemId } } },
    );
    if (result.matchedCount === 0) return res.status(404).json({ error: 'Business not found' });
    if (result.modifiedCount === 0) return res.status(404).json({ error: 'Menu item not found' });

    // Clean up Cloudinary asset (non-fatal — item is already removed from DB)
    if (imagePublicId) await deleteMenuImage(imagePublicId);

    scheduleWaCatalogSync(tenantId);
    res.json({ ok: true });
  } catch (err) {
    logger.error('[Business] deleteMenuItem failed', { err: err.message });
    res.status(500).json({ error: err.message });
  }
}

export async function getModeInfo(req, res) {
  try {
    const { mode } = req.query;
    const fakeBiz = { businessMode: mode || 'RESTAURANT' };
    const cfg = getModeConfig(fakeBiz);
    res.json({ mode: cfg.businessMode, flows: cfg.flows, steps: cfg.steps, ui: cfg.ui });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

/**
 * [CATALOG-SYNC-ROUTE-1] POST /:tenantId/wacatalog/sync
 * Manual, tenant-triggered push of BusinessConfig.menuItems into the
 * tenant's Meta Commerce Catalog via waCatalogService.syncMenuToCatalog().
 * Previously this function was fully written and unit-tested but had zero
 * callers anywhere in the app.
 */
export async function syncWaCatalog(req, res) {
  try {
    const { tenantId } = req.params;

    const business = await BusinessConfig.findOne({ tenantId }).lean();
    if (!business) return res.status(404).json({ error: 'Not found' });

    // The enabled/catalogId guard runs BEFORE the Tenant document is fetched —
    // a misconfigured tenant gets a clear 400 instead of an unnecessary DB
    // round-trip followed by a confusing downstream Graph API failure.
    if (!business.waCatalog?.enabled || !business.waCatalog?.catalogId) {
      return res.status(400).json({ error: 'WA Catalog is not enabled or has no catalogId configured for this tenant.' });
    }

    // .lean() is required here — Tenant's toJSON transform strips
    // accessToken, and syncMenuToCatalog() needs the raw encrypted token to
    // decrypt and call the Graph API.
    const { default: Tenant } = await import('../models/Tenant.js');
    const tenant = await Tenant.findById(tenantId).lean();
    if (!tenant) return res.status(404).json({ error: 'Tenant not found' });

    const { syncMenuToCatalog } = await import('../modules/catalog/waCatalogService.js');
    const result = await syncMenuToCatalog(business, tenant);

    if (!result.ok) {
      // NO_TOKEN/NO_CATALOG_ID are caller-fixable configuration problems (400);
      // everything else (GRAPH_ERROR, NETWORK_ERROR) is an upstream failure (502).
      const status = result.reason === 'NO_TOKEN' || result.reason === 'NO_CATALOG_ID' ? 400 : 502;
      return res.status(status).json({ error: `WA Catalog sync failed: ${result.reason}` });
    }

    res.json({ ok: true, synced: result.synced, deleted: result.deleted || 0 });
  } catch (err) {
    logger.error('[Business] syncWaCatalog failed', { err: err.message });
    res.status(500).json({ error: err.message });
  }
}

export async function listSupportedModes(_req, res) {
  try {
    res.json({ modes: getSupportedModes() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
